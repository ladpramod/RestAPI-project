package com.info.services;

import com.info.entity.StudentData;

public interface StudentSevice {

	StudentData saveStudent(StudentData data);
}
