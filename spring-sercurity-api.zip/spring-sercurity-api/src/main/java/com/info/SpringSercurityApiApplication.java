package com.info;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSercurityApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSercurityApiApplication.class, args);
	}

}
